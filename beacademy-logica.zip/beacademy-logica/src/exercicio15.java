import java.util.Scanner;

public class exercicio15 {

    public static void main(String[] args) {

        double saque, deposito, transferencia;
        int operacao, numeroBanco, numeroAgencia, numeroConta;
        double valorInicial = 50.0;
        double valorFinal;

        System.out.print("1 - Saque\n"
                        + "2 - Deposito\n"
                        + "3 - Transferencia\n" + "Digite a operacao desejada: "
                        );

        Scanner operation = new Scanner(System.in);
        operacao = operation.nextInt();



        switch(operacao) {
            case 1:
                System.out.print("Digite o valor do saque: ");
                Scanner retirar = new Scanner(System.in);
                saque = retirar.nextDouble();
                valorFinal = valorInicial - saque;
                retirar.close();
                System.out.println("Valor Inicial da conta: " + valorInicial
                        + "\nSaque de: " + saque + '\n' + "Valor Final na conta: " + valorFinal);
                break;
            case 2:
                System.out.print("Digite o valor do deposito: ");
                Scanner deposit = new Scanner(System.in);
                deposito = deposit.nextDouble();
                valorFinal = valorInicial + deposito;
                deposit.close();
                System.out.println("Valor Inicial da conta: " + valorInicial
                        + "\nDeposito de: " + deposito + '\n' + "Valor Final na conta: " + valorFinal);
                break;
            case 3:
                System.out.print("Digite o valor da transferencia: ");
                Scanner transfer = new Scanner(System.in);
                transferencia = transfer.nextDouble();
                valorFinal = valorInicial - transferencia;

                System.out.print("Digite o numero do banco: ");
                Scanner bank = new Scanner(System.in);
                numeroBanco = bank.nextInt();
                System.out.print("Digite o numero da agencia sem o digito: ");
                Scanner agency = new Scanner(System.in);
                numeroAgencia = agency.nextInt();
                System.out.print("Digite o numero da conta: ");
                Scanner count = new Scanner(System.in);
                numeroConta = count.nextInt();


                System.out.println("Valor Inicial da conta: " + valorInicial
                        + "\nTransferencia de: " + transferencia + '\n' + "Valor Final na conta: " + valorFinal +
                        "\n Banco destino: " + numeroBanco + "\nAgencia destino: " + numeroAgencia + "\n Conta destino: " + numeroConta
                );
                bank.close();
                agency.close();
                count.close();
                transfer.close();
                break;
            default:
                System.out.println("Opcao nao existente");
        }
        operation.close();


    }
}

