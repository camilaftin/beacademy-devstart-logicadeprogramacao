import java.util.Scanner;

public class exercicio2 {

    public static void main(String[] args) {


        double numero1, numero2;
        Scanner n1 = new Scanner(System.in);
        Scanner n2 = new Scanner(System.in);

        System.out.print("Digite o primeiro numero: ");
        numero1 = n1.nextDouble();
        System.out.print("Digite o segundo numero: ");
        numero2 = n2.nextDouble();

        n1.close();
        n2.close();

        System.out.println("A soma dos numeros: " + (numero1 + numero2) );

    }
}
