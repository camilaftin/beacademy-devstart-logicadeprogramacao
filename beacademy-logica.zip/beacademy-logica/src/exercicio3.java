import java.util.Scanner;
public class exercicio3 {

    public static void main(String[] args) {


        String nome;
        double peso;
        double altura;

        System.out.print("Digite seu nome: ");
        Scanner name = new Scanner(System.in);
        nome = name.nextLine();
        System.out.print("Digite seu peso com virgula: ");
        Scanner weight =  new Scanner (System.in);
        peso = weight.nextDouble();
        System.out.print("Digite sua altura em metros (uso de virgula): ");
        Scanner height = new Scanner(System.in);
        altura = height.nextDouble();

        name.close();
        weight.close();
        height.close();

        System.out.println("Nome: " + nome + '\n' +
                            "Peso: " + peso + '\n'+
                            "Altura em metros: " + altura
                          );

        //IMC eh calculado usando o peso pela divisao da altura ao quadrado

        System.out.println("Seu IMC calculado com os dados informados: " +
                        (peso/(altura*altura)));




    }
}
