import java.util.Scanner;

public class exercicio9 {

    public static void main(String[] args) {

        double altura, peso, imc = 0.0;

        System.out.print("Digite sua altura com virgula: ");
        Scanner height = new Scanner(System.in);
        altura = height.nextDouble();
        System.out.print("Digite seu peso: ");
        Scanner weight = new Scanner(System.in);
        peso = weight.nextDouble();

        height.close();
        weight.close();
        imc = peso / (altura*altura);

        if( imc < 19 ){
            System.out.println("Abaixo do peso");
        } else if( imc >= 19 && imc < 25 ){
            System.out.println("Peso normal");
        } else if ( imc >= 25 && imc < 30 ){
            System.out.println("Sobrepeso");
        } else if ( imc >= 30 && imc < 40 ){
            System.out.println("obesidade tipo I");
        } else if ( imc >= 40 ){
            System.out.println("obesidade morbida");
        }
    }
}
