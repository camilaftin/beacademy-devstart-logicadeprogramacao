import java.util.Scanner;

public class exercicio22 {

    public static void main(String[] args) {

        String nome;
        String senha;


        do{
            System.out.print("Digite seu nome: ");
            Scanner name = new Scanner(System.in);
            nome = name.nextLine();

            System.out.print("Digite sua senha: ");
            Scanner password = new Scanner(System.in);
            senha = password.nextLine();


        }while (!senha.equals("paylivre") && (!nome.equals("Marcos") || !nome.equals("marcos")));
        System.out.println("Logado com sucesso");
    }
}
