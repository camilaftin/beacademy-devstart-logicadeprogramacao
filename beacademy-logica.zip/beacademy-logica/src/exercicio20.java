import java.util.Scanner;

public class exercicio20 {

    public static void main(String[] args) {

        int numero, j = 0;

        System.out.print("Digite um numero: ");
        Scanner number = new Scanner(System.in);
        numero = number.nextInt();

        while ( j < numero ){
            System.out.println( j + " X " + numero + " = " + j*numero);
            j++;
        }
        number.close();
    }
}
