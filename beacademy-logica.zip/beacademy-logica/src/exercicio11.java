import java.util.Scanner;

public class exercicio11 {

    public static void main(String[] args) {

        double depositoValor, saqueValor;
        double saldoFinal = 0.0;
        int escolha;

        System.out.print("Deseja depositar (1) ou saque(2): ");
        Scanner choice = new Scanner(System.in);
        escolha = choice.nextInt();

        switch (escolha){

            case 1:
                System.out.print("Digite o valor do deposito: ");
                Scanner deposito = new Scanner(System.in);
                depositoValor = deposito.nextDouble();
                saldoFinal += depositoValor;
                System.out.println("Valor deposito: " + depositoValor + '\n'
                + "Operacao escolhida de deposito " + '\n' +
                        "Saldo: " + saldoFinal);
                break;
            case 2:
                System.out.print("Digite o valor do saque: ");
                Scanner saque = new Scanner(System.in);
                saqueValor = saque.nextDouble();
                saldoFinal -= saqueValor;
                System.out.println("Valor saque: " + saqueValor + '\n'
                        + "Operacao escolhida de saque " + '\n' +
                        "Saldo: " + saldoFinal);
                break;
        }

    }
}
