public class exercicio21 {

    public static void main(String[] args) {

        int j;
        System.out.print("Imprimindo de 1 a 10 com enquanto:\n");
        j = 1;
        while( j < 11 ) {
            System.out.println(j);
            j++;
        }
    }
}
