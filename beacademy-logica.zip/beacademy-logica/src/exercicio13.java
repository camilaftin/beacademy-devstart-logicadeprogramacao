import java.util.Scanner;

public class exercicio13 {

    public static void main(String[] args) {

        double numero1, numero2;
        String operacao;
        double resultado;

        System.out.print("Digite o primeiro numero: ");
        Scanner number1 = new Scanner(System.in);
        numero1 = number1.nextDouble();
        System.out.print("Digite a operacao desejada + , - , * , / : ");
        Scanner operation = new Scanner(System.in);
        operacao = operation.nextLine();
        System.out.print("Digite o segundo numero:  ");
        Scanner number2 = new Scanner(System.in);
        numero2 = number2.nextDouble();

        number1.close();
        operation.close();
        number2.close();


        switch(operacao){
            case "+":
                resultado = numero1 + numero2;
                break;
            case "-":
                resultado = numero1 - numero2;
                break;
            case "*":
                resultado = numero1 * numero2;
                break;
            case "/":
                resultado = numero1 / numero2;
                break;
            default:
                resultado = -1;
        }
        System.out.print("Resultado: " + resultado);

    }

}

