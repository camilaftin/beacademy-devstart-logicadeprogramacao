import java.util.Scanner;

public class exercicio17 {

    public static void main(String[] args) {


        int numeroEscolhido;

        System.out.print("Digite o numero qualquer: ");
        Scanner number = new Scanner(System.in);
        numeroEscolhido = number.nextInt();
        System.out.println("Tabuada do numero: ");

        for(int i = 0; i < numeroEscolhido; i++){
            System.out.println(numeroEscolhido + " X " + i + " = " + numeroEscolhido*i);
        }
        number.close();
    }
}
