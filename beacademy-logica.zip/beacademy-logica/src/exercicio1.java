import java.util.Scanner;

public class exercicio1 {

    public static void main(String[] args){
        String name;

        System.out.print("Digite seu nome: ");
        Scanner nam = new Scanner (System.in);
        name = nam.nextLine();
        System.out.println("Seja bem-vindo: " + name);

        nam.close();
    }
}
