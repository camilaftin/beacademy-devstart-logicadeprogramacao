import java.util.Scanner;

public class exercicio4 {

    public static void main(String[] args) {


        String nome;
        int idade;

        System.out.print("Digite seu nome: ");
        Scanner name = new Scanner(System.in);
        nome = name.nextLine();
        System.out.print("Digite sua idade: ");
        Scanner age = new Scanner(System.in);
        idade = age.nextInt();

        name.close();
        age.close();

        System.out.println("Nome informado: " + nome + '\n' +
                            "Idade informada: " + idade);

        if( idade > 18 ){
            System.out.println("Verdadeiro para idade acima de 18");
        }
        if ( idade != 25 ){
            System.out.println("Falso para idade diferente de 25");
        }
        if( idade != 25 && nome.equals("Marcos")){
            System.out.println("Falso para a idade diferente de 25 E o nome igual a Marcos");
        }
        if( idade != 25 || nome.equals("Marcos")){
            System.out.println("Verdadeiro para idade diferente de 25 OU nome igual a Marcos");
        }
        if((idade%2) == 0){
            System.out.println("Verdadeiro para divisao da idade");
        }
    }
}
