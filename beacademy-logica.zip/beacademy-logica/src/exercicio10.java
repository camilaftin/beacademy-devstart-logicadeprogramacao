import java.util.Scanner;

public class exercicio10 {

    public static void main(String[] args) {

        int idade;

        System.out.print("Digite sua idade: ");
        Scanner age = new Scanner(System.in);
        idade = age.nextInt();

        age.close();

        if( idade < 18 ){
            System.out.println("Menor de idade");
        } else if ( idade >= 18 && idade < 60){
            System.out.println("Adulto");
        } else{
            System.out.println("Idoso");
        }
    }
}
