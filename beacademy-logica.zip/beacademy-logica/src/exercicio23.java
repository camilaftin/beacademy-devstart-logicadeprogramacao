import java.util.Scanner;

public class exercicio23 {

    public static void main(String[] args) {

        int numero1, numero2;
        int opcao;
        //int soma, multiplicacao, diferenca;
        double divisao;


        do{

            System.out.print("Digite o primeiro numero diferente de zero: ");
            Scanner number1 = new Scanner(System.in);
            numero1 = number1.nextInt();
            System.out.print("Digite o segundo numero diferente de zero: ");
            Scanner number2 = new Scanner(System.in);
            numero2 = number2.nextInt();
            divisao = numero1/numero2;
            System.out.println("Soma: " + (numero1 + numero2) + "\n"
                               + "Multiplicacao: " + numero1*numero2 + "\n"
                               + "Diferenca: " + (numero1-numero2) + "\n"
                               + "Divisao: " + divisao);

            System.out.println("Deseja realizar novo calculo? 0 - nao e 1 - sim");
            Scanner option = new Scanner(System.in);
            opcao = option.nextInt();

        }while (opcao != 0);

    }
}
