import java.util.Scanner;

public class exercicio19 {

    public static void main(String[] args) {


        int numero1, numero2;

        System.out.print("Digite o primeiro numero: ");
        Scanner number1 = new Scanner(System.in);
        numero1 = number1.nextInt();
        System.out.print("Digite o segundo numero: ");
        Scanner number2 = new Scanner(System.in);
        numero2 = number2.nextInt();

        if (numero1 > numero2) {
            for (int i = numero2; i <= numero1; i++) {
                if (i % 3 == 0) {
                    System.out.println(i);
                }
            }
        } else {
            for (int i = numero1; i <= numero2; i++) {
                if (i % 3 == 0) {
                    System.out.println(i);
                }
            }
        }

        number1.close();
        number2.close();
    }
}

