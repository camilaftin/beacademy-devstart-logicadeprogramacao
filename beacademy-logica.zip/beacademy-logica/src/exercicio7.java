import java.util.Scanner;

public class exercicio7 {

    public static void main(String[] args) {

        String nome;
        double salario;

        System.out.print("Digite seu nome: ");
        Scanner name = new Scanner(System.in);
        nome = name.nextLine();
        System.out.print("Digite seu salario: ");
        Scanner salary = new Scanner(System.in);
        salario = salary.nextDouble();

        salary.close();
        name.close();
        if( salario > 1200 ){
            System.out.println(nome + " seu salario eh maior que o minimo de 1200 que eh " + salario);
        }else{
            System.out.println(nome + " seu salario eh menor que o minimo de 1200 que eh " + salario);
        }

    }
}
