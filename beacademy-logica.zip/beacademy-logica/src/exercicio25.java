public class exercicio25 {

    public static void main(String[] args) {

        int j = 0;
        int soma = 0;

        System.out.println("A soma dos 100 primeiros numeros:");

        do{
            soma += j;
            System.out.println(soma);
            j++;
        }while ( j < 101);
    }
}
