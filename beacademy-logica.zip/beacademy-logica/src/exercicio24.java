public class exercicio24 {

    public static void main(String[] args) {

        int j;
        System.out.println("Imprimindo de 1 a 10 - repita até: ");
         j = 1;

         do{
             System.out.println(j);
             j++;
         }while( j != 10);
    }
}
