import java.util.Scanner;

public class exercicio14 {

    public static void main(String[] args) {

        double base, altura;
        String figuraGeometrica;
        double area;

        System.out.print("Digite a base: ");
        Scanner basi = new Scanner(System.in);
        base = basi.nextDouble();
        System.out.print("Digite a operacao desejada Q-quadrado ou T-triangulo : ");
        Scanner operation = new Scanner(System.in);
        figuraGeometrica = operation.nextLine();
        System.out.print("Digite a altura:  ");
        Scanner height = new Scanner(System.in);
        altura = height.nextDouble();

        basi.close();
        operation.close();
        height.close();

        switch(figuraGeometrica.toUpperCase()){
            case "Q":
                area = base * altura;
                break;
            case "T":
                area = (base*altura)/2;
                break;
            default:
                area = -1;
        }
        System.out.print("Area da figura escolhida: " + area);
    }
}
