import java.util.Scanner;

public class exercicio5 {


    public static void main(String[] args) {

        double valor = 0.0;
        double saldoInicial = 100.0;
        double saldoFinal = 0.0;



        System.out.print("Valor que deseja depositar: ");
        Scanner deposito = new Scanner(System.in);
        valor = deposito.nextDouble();
        saldoFinal = saldoInicial + valor;

        deposito.close();

        System.out.println("Saldo inicial: " + saldoInicial + '\n' +
                            "Valor do deposito: " + valor +'\n' +
                            "Saldo atual: " + saldoFinal);




    }
}
