public class exercicio16 {

    public static void main(String[] args) {


        int contador;

        System.out.print("Escrevendo numero de 1 a 10:\n");
        for(contador = 1; contador < 11; contador++){
            System.out.println(contador);
        }
    }
}
